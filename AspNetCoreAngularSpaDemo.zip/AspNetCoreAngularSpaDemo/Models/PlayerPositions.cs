﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreAngularSpaDemo.Models
{
    public enum PlayerPositions
    {
        Goalkeeper,
        Defender,
        Midfielder,
        Forward
    }
}
